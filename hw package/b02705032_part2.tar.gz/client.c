#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>

void error(char *msg){
	perror(msg);
	exit(1);
};

int main(int argc, const char *argv[])
{
	int sockfd, port, n;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	char buffer[1024], temp[25];
	bool command_s, exit_s, logined;
	logined = false;
	if(argc<3){
		fprintf(stderr, "usage %s hostname port", argv[0]);
		exit(0);
	}
	port = atoi(argv[2]);
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd<0)
		error("ERROR opening socket");
	server = gethostbyname(argv[1]);
	if(server==NULL){
		fprintf(stderr, "ERROR, no such host");
		exit(0);
	}
	bzero((char*) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	bcopy((char*) server->h_addr, (char*) &serv_addr.sin_addr.s_addr, server->h_length);
	serv_addr.sin_port = htons(port);
	if(connect(sockfd, (struct sockaddr*) &serv_addr, sizeof(serv_addr))<0)
		error("ERROR connecting");
	printf("Welcome to the system\n");
	bzero(buffer, 1024);
	n = read(sockfd, buffer, 1024);
	printf("%s", buffer);
	while(1){
		printf("\n----------------------------------------------------\n");
		if(!logined)
			printf("1. Register  2. Log In\n");
		else
			printf("1. Account List  2. Exit\n");
		printf("Please enter the service number: ");
		bzero(buffer, 1024);
		scanf("%s", buffer);
		switch(atoi(buffer)){
			case 1:
				if(!logined){
					do{
						printf("Please enter an account name (within 9 characters): ");
						bzero(temp, 25);
						scanf("%s", temp);
						if(strlen(temp)>9)
							printf("Account name is too long, please enter again.\n");
					}while(strlen(temp)>9);
					bzero(buffer, 1024);
					strcpy(buffer, "REGISTER#");
					strcat(buffer, temp);
					command_s = true;
					exit_s = false;
				}
				else{
					bzero(buffer, 1024);
					strcat(buffer, "List");
					command_s = true;
					exit_s = false;
				}
					break;
			case 2:
				if(!logined){
					printf("Please enter your account name: ");
					bzero(buffer, 1024);
					scanf("%s", buffer);
					printf("Please enter your port number: ");
					bzero(temp, 25);
					scanf("%s", temp);
					strcat(buffer, "#");
					strcat(buffer, temp);
					command_s = true;
					exit_s = false;
				}
				else{
					bzero(buffer, 1024);
					strcat(buffer, "Exit");
					command_s = true;
					exit_s = true;
				}
				break;
			default:
				printf("Unknown command, please retry.\n");
				command_s = false;
				exit_s = false;
				break;
		}
		if(command_s){
			n = write(sockfd, buffer, strlen(buffer));
			if(n<0)
				error("ERROR writing to socket");
			bzero(buffer, 1024);
			n = read(sockfd, buffer, 1024);
			if(buffer[0] == 'A')
				logined = true;
			if(n<0)
				error("ERROR reading from socket");
			printf("%s", buffer);
		}
		if(exit_s){
			printf("\n");
			close(sockfd);
			break;
		}
	}

	return 0;
}
