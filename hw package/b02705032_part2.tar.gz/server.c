#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <pthread.h>

int sockfd, port, clilen, n, online_number = 0;
struct sockaddr_in serv_addr, cli_addr;
char buffer[1024], temp[1024];
struct list *head_list= NULL;

void error(char *msg){
	perror(msg);
	exit(1);
};

struct user{
	char name[20];
	int balance;
};

struct list{
	struct user u;
	char ip_addr[15];
	int port;
	struct list* next;
};

void account_list(struct list* myUser, char* buffert){
	bzero(buffert, 1024);
	char temp[100];
	sprintf(buffert, "Account: %s, Balance: %d\n%d online users.\n", myUser->u.name, myUser->u.balance, online_number);
	struct list* cur;
	int count = 1;
	for(cur=head_list;cur!=NULL;cur = cur->next){
		bzero(temp, 100);
		sprintf(temp, "The %d's username is %s. From IP: %s and port: %d\n", count, cur->u.name, cur->ip_addr, cur->port);
		strcat(buffert, temp);
		count++;
	}
	
};

void* thread_go(void* psocket){
	int passsocket = *(int*) psocket;
	char buffert[1024], tempt[1024];
	struct list* me = malloc(sizeof(struct list));
	bzero(me->u.name, 20);
	printf("Connecting to a client!\n");
	fflush(stdout);
	bzero(buffert, 1024);
	while(n=read(passsocket, buffert, 1024)){
		if(n<0)
			error("ERROR reading from socket");
		bool loginned = false, isReg=false;
		if(strncmp(buffert, "REGISTER#", 9)==0){
			bzero(tempt, 1024);
			for(n=9;n<strlen(buffert);n++)
				tempt[n-9] = buffert[n];
			FILE *fp;
			fp = fopen("register.txt", "r");
			if(fp==NULL)
				error("ERROR on open file");
			bzero(buffert, 1024);
			isReg = false;
			if(strcmp("REGISTER", tempt)!=0&&strcmp("List", tempt)!=0&&strcmp("Exit", temp)!=0){
				while(fgets(buffert, 1024, fp)!=NULL){
					if(strncmp(tempt, buffert, strlen(tempt))==0){
						isReg = true;
						break;
					}
					fgets(buffert, 1024, fp);
					bzero(buffert, 1024);
				}
			}
			bzero(buffert, 1024);
			if(!isReg){
				strcat(tempt, "\n1000\n");
				fclose(fp);
				fp = fopen("register.txt", "a");
				fwrite(tempt, 1, strlen(tempt), fp);
				strcpy(buffert, "100 OK\n");
			}
			else
				strcpy(buffert, "210 FAIL\n");
			fclose(fp);
		}
		else if(strncmp(buffert, "List", 4)==0 && strlen(buffert)==4){
			account_list(me, buffert);
			printf("%s: List\n", me->u.name);
			fflush(stdout);
		}
		else if(strncmp(buffert, "Exit", 4)==0 && strlen(buffert)==4){
			printf("%s leaved!\n", me->u.name);
			fflush(stdout);
			struct list *cur = head_list, *pre = NULL;
			while(true){
				if(cur==me){
					if(pre==NULL)
						head_list = cur->next;
					else{
						pre->next = cur->next;
					}
					free(cur);
					cur = NULL;
					pre = NULL;
					me = NULL;
					online_number--;
					break;
				}
				else{
					pre = cur;
					cur = cur->next;
				}
			}
			bzero(buffert, 1024);
			strcpy(buffert, "bye!\n");
			n = write(passsocket, buffert, 1024);
			free(psocket);
			pthread_exit(NULL);
		}
		else{//login
			int no_pos, i;
			bool is_double_loginned=false;
			bzero(tempt, 1024);
			for(no_pos=0;no_pos<strlen(buffert);no_pos++){
				if(buffert[no_pos]=='#')
					break;
				tempt[no_pos] = buffert[no_pos];
			}
			struct list *cur = head_list;
			while(cur!=NULL){
				if(strncmp(tempt, cur->u.name, strlen(tempt))==0)
					is_double_loginned = true;
				cur = cur->next;
			}
			if(!is_double_loginned){
				strcpy(me->u.name, tempt);
				bzero(tempt, 1024);
				for(i=no_pos+1;i<strlen(buffert);i++){
					tempt[i-no_pos-1] = buffert[i];
				}
				me->port = atoi(tempt);
				strcpy(me->ip_addr, inet_ntoa(cli_addr.sin_addr));//get client ip
				FILE *fp;
				fp = fopen("register.txt", "r");
				bzero(tempt, 1024);
				bzero(buffert, 1024);
				strcpy(tempt, me->u.name);
				while(fgets(buffert, 1024, fp)!=NULL){
					if(strncmp(tempt, buffert, strlen(tempt))==0){
						loginned = true;
						break;
					}
					fgets(buffert, 1024, fp);
					bzero(buffert, 1024);
				}
				if(loginned){
					bzero(buffert, 1024);
					fgets(buffert, 1024, fp);
					if(buffert[strlen(buffert)-1]=='\n')
						buffert[strlen(buffert)-1]='\0';
					me->u.balance = atoi(buffert);
					me->next = head_list;
					head_list = me;
					online_number++;
				}
				fclose(fp);
				account_list(me, buffert);
				printf("%s logged in!\n", me->u.name);
				fflush(stdout);
			}
			else{
				bzero(buffert, 1024);
				strcpy(buffert, "Failed, double loggined.\n");
			}
		}
		n = write(passsocket, buffert, 1024);
		if(n<0)
			error("ERROR writing socket.");
		bzero(buffert, 1024);
	}
	if(me->u.name[0]!='\0'){
		struct list *cur = head_list, *prev = NULL;
		while(cur!=NULL){
			if(cur==me)
				break;
			prev = cur;
			cur = cur->next;
		}
		if(prev!=NULL)
			prev->next = cur->next;
		free(cur);
	}
	printf("A client disconnected\n");
	fflush(stdout);
	pthread_exit(NULL);

};

int main(int argc, const char *argv[]){
	pthread_t tid = 0;
	int newsockfd;
	if(argc<2){
		fprintf(stderr, "ERROR, no port provided");
		exit(1);
	}
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd<0)
		error("ERROR opening socket");
	bzero((char*) &serv_addr, sizeof(serv_addr));
	port = atoi(argv[1]);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(port);
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	if(bind(sockfd, (struct sockaddr*) &serv_addr, sizeof(serv_addr))<0)
		error("ERROR on binding");
	listen(sockfd, 5);
	clilen = sizeof(cli_addr);
	while(newsockfd=accept(sockfd, (struct sockaddr*) &cli_addr, &clilen)){
		if(newsockfd<0)
			error("ERROR on accept");
		else{
			bzero(buffer, 1024);
			n = write(newsockfd, "Welcome! Please Register or Login!\n", 100);
			if(n<0)
				error("ERROR writing to socket");
			int* passsocket = malloc(sizeof(int));
			*passsocket = newsockfd;
			pthread_create(&tid, NULL, thread_go, passsocket);
		}
	}

	return 0;

}
